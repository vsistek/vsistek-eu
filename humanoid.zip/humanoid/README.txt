 █  █ vsistek.eu
  ██  presents
        
█ █ █ █ █   █  █  █  █ ███ █ ██
███ █ █ ██ ██ ███ ██ █ █ █ █ █ █
█ █ ███ █ █ █ █ █ █ ██ ███ █ ██

When I was 17, I had a plan to create
a space travelling adventure game.
I got it to a point of a working 
prototype of the game interface.
It is a Windows 32-bit GUI executable.

File name:  project.exe
Dependency: msvbvm60.dll

Tip: Try double clicking the red planet!

(c) Vaclav Sistek 2001
